``````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````			#include<stdio.h>
#include<stdint.h>
#include<stm32f446xx.h>
#include "CLOCK.h"

void GPIO_Config(void);
void delay(uint32_t time);
void TIM6Config(void);
void Delay_us(uint16_t us);
void Delay_ms (uint16_t ms);
void USART2Config(void);
void USART2SendChar(uint8_t c);
void USART2SendString(char *s);
uint8_t USART2GetChar(void);



void GPIO_Config(void){
	// 1  Enable GPIO clock
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	
	// 2. Set the pin as output
	
	GPIOA->MODER |= (1<<10); // sets the 10th bit as 1. 11th bit is 1 by default. pin PA5 is set as output
	
	// 3. Configure the output mode
	GPIOA->OTYPER = 0; 
	GPIOA->OSPEEDR = 0; // using low speed
	
}

void delay(uint32_t time){
	while (time--);
}


void TIM6Config(void){
	// 1. Enable timer clock TIM6 in this case
	RCC->APB1ENR |= (1<<4); //6.3.13
	
	// 2. Setup the prescaler and the ARR
	TIM6->PSC = 60 - 1; // Whatever value that we want we have to substract 1 from it. The APB1 bus is set to 90MHz in this case. so the timer will be 90MHz/90 = 1MHz ||  1us delay
	//19.4.7
	
	TIM6->ARR = 0xffff ; //max value of ARR so the timer CAN1 have maximum value
	//19.4.9

	// 3. Enable the timer and wait for the update flag to set
	TIM6->CR1 |= (1<<0); // Enable the counter
	//19.4.1
	while(!(TIM6->SR & (1<<0))); // waiting for the TIM6 to set
	//19.4.4
}

void Delay_us(uint16_t us){
	// 1. Reset to counter
	TIM6->CNT = 0;
	//19.4.6
	// Wait for the counter for the us value. Each count will mean 1 us has passed
	while(TIM6->CNT < us);
		
}


void Delay_ms(uint16_t ms){
	
	for (uint16_t i = 0 ; i<ms;i++){
		Delay_us(1000);
	}		

		
}


void USART2Config(void){
	
	// 1 Enable the UART clock
	RCC->APB1ENR |= (1<<17); // Enable UART2 clock
	
	// 2 Enable GPIOA clock for TX and RX pins
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	
	// 3 Configure the UART pins for alternate functions
	GPIOA->MODER |= (2<<4); // Bits [5:4] = 1:0--> Alternate function for pin PA2
	GPIOA->MODER |= (2<<6); // Bits [6:7] = 1:0--> Alternate function for pin PA3
	
	GPIOA->OSPEEDR |= (3<<4) | (3<<6); //High speed for pin PA2 and PA3 
	
	GPIOA->AFR[0] |=(7<<8); // 0 for low alternate register 1 for hight alternate register
	GPIOA->AFR[0] |=(7<<12);
	
	// 3 Enable the USART 
	USART2->CR1 = 0x00;
	USART2->CR1 |= (1<<13); // Enable USART2
	
	// 4 Set the word length 
	USART2->CR1 &= ~(1U<<12); // M= 0 means 8 bit word length
	
	// 5 select the baud rate
	USART2->BRR |= (3<<0) | (16<<4); //115200 PLK1 at 45MHz
	
	
	//  6. Enable TX and RX in USART_CR1 register
	USART2->CR1 |= (1<<2); // enable RE for receiver 
	USART2->CR1 |= (1<<3); //enable TE for transmitter
}


void USART2SendChar(uint8_t c){
	// 1 Write the data to be sent in the USART2->DR
	
	USART2->DR = c; 
	while(!(USART2->SR &(1<<6))); // Wait for TC to set. This indicates that the data has been transmitter
	
	
}

void USART2SendString(char *s){
	
	
	while(*s){
		USART2SendChar(*s++);
		
	}
	
}

uint8_t USART2GetChar(void){
	
	// 1 Check the status register
	while(!(USART2->SR & (1<<5)));
	
	// 2 Read the data from the data register
	uint8_t temp;
	temp = (uint8_t) USART2->DR;
	
	return temp;
}




int main(void){
	initClock();
	GPIO_Config();
	TIM6Config();
	USART2Config();
	
	//GPIOA->BSRR |= (1<<5);
	
	USART2SendString("WELCOME\n\0");
	
	while(1){
	GPIOA->BSRR |= (1<<5); // set pin PA5
	//USART2SendString("WELCOME\n\0");
	USART2SendString("Hello\n\0");
	Delay_ms(1000);
	GPIOA->BSRR |= ((1<<5)<<16);
	Delay_ms(1000);
			
	}

	
}
