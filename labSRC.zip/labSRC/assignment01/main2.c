#include<stm32f446xx.h>
#include"USART.h"
#include"CLOCK.h"
#include"DELAY.h"
#include"GPIO.h"
#include"USART.h"



int main(void){
	initClock();
	TIM6Config();
	GPIOA_Config();
/*	Blinks the led in the microcontroller board
	while(1){
		GPIOA->BSRR |= (1<<5);
		Delay_ms(100);
		GPIOA->BSRR |= ((1<<5)<<16);
		Delay_ms(100);
	}
*/
	
	// UART communication
	
	UART2_Config();
	Delay_ms(3000);
	UART_SendString(USART2,"                   WELLCOME\n");
	Delay_ms(3000);
	UART_SendString(USART2,"This is a Demonstration of UART communication by\nImran and Munni\n");
	Delay_ms(2000);
	char ch[12];
	//UART_GetString(USART2,7,ch);
	while(1){
		
		UART_SendString(USART2,"--HELLO\n");
		Delay_ms(1500);
		
		
	}
	
	
}

